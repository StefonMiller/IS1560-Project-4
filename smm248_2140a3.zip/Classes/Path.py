
# uncompleted address of preprocessed corpus.
ResultHM1="data//result."

# address of generated Text index file.
IndexTextDir="data//indextext//"

# address of generated Web index file.
IndexWebDir="data//indexweb//"

# Address of text file containing topics
TopicDir="data//topics.txt"

StopWordsDir="data//stopword.txt"